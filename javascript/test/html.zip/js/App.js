'use strict';  // Happy Coding :)
